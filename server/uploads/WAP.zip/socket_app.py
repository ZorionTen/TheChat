import eventlet
import socketio
messages = []
ips = {}
sio = socketio.Server(cors_allowed_origins="*")
app = socketio.WSGIApp(sio, static_files={
    '/': {'content_type': 'text/html', 'filename': 'web/index.html'},
    '/script.js': {'content_type': 'text/javascript', 'filename': 'web/script.js'},
    '/style.css': {'content_type': 'text/css', 'filename': 'web/style.css'},
})

@sio.event
def connect(sid, environ):
    ips[sid]=environ['REMOTE_ADDR']
    print('connect ', sid)
    sio.emit('command',{'data':{'ip':environ['REMOTE_ADDR']}},to=sid)
    sio.emit('command',{'data':{'members':list(ips.values())}})

@sio.event
def message(sid, data):
    mes={**data,'from':ips[sid],'sid':sid}
    messages.append(mes)
    if len(messages)> 100:
        messages.pop(0)
    sio.emit('message',[mes])

@sio.event
def command(sid, data):
    if data =='history':
        return messages
    if data=='members':
        return ips

@sio.event
def disconnect(sid):
    del ips[sid]
    print('disconnect ', sid)

if __name__ == '__main__':
    # lis = eventlet.listen(('0.0.0.0', 51998),certfile="localhost.crt", keyfile="localhost.key", server_side=True)
    # eventlet.wsgi.server(eventlet.wrap_ssl(lis), app)
    eventlet.wsgi.server(eventlet.listen(('0.0.0.0', 51998)), app)